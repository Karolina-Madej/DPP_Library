def HelloWorld():
    print("Hello World")

def HelloWorldInPolish():
    print("Dzień Dobry Świecie")

def HelloWorldInFrench():
    print("Bonjour le Monde!")

def HelloWorldInGerman():
    print("Hallo Welt")

def HelloWorldInItaly():
    print("Ciao Mondo")
